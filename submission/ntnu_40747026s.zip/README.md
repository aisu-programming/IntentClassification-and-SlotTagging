# Homework 1 ADL NTU 109 Spring

### Training model
There are python programs named `train_intent.py` and `train_slot.py`.
Simply execute them to train the model.

### Test model
There are bash scripts named `intent_cls.sh` and `slot_tag.sh`, and there are python programs named `test_intent.py` and `test_slot.py`.
Simply execute them to train the model.
These files are all in the format which the professor have assigned, so remember to add the arguments such as `--ckpt_path` or `--test_file`.